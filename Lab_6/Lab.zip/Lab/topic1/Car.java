
public class Car {

    static String color = "Red";
    int seat;

    public static void main(String[] args) {
        int price;
        Car Toyota = new Car();
        Toyota.color = "Black";
    }
}
