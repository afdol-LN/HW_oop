
class MyClass
{
    public int A;
    static int B; //class variable เพราะใช้ static
    public MyClass()
    {
        A = 0;
        B = 1;
    }
}