import java.lang.*;
class Lab4_2
{
   public static void main(String[] args) 
   {
      int weight, height;
      int num1;
      float radius;		
      double area;
      long factorial;
      short intfe;
      char ch1, ch2;
      System.out.println("This is my first Java Programming");
   }
}
