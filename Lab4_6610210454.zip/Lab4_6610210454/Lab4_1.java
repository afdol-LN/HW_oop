class Lab4_1{
    public static void main(String[] args) {
        int i =3;
        long l = 200000;
        double d = 35.4;
        char c = '4';
        boolean b = true;
        String title = "Java Programming";

        //output
        System.out.println(i);
        System.out.println(l);
        System.out.println(d);
        System.out.println(c);
        System.out.println(b);
        System.out.println(title);
    };
}