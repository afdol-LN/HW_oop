import java.lang.*;
class Lab4_3
{
  static double rate = 4.25;
  static double PI = 3.1459;
  public static void main(String[] args) 
  {
       rate = 3.25;
       PI = PI + 3.20;
       System.out.println("rate="+rate);
       System.out.println("PI="+PI);
  }
}
