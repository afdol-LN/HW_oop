public  class Letter {

         char c;}