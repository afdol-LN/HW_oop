public class Value {
 
    int i;
 
}
