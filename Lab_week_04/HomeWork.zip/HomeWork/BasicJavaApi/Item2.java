

public class Item2 {
    public static void main(String[] args) {
        NumberHolder number1 = new NumberHolder(50, 1.57f);
        number1.showAnInt();
        number1.showAfloat();
    }
    
}
